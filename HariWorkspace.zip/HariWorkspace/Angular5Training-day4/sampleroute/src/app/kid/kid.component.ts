import { Component, OnInit, OnChanges, SimpleChange, SimpleChanges, AfterContentInit, OnDestroy, Input } from '@angular/core';

@Component({
  selector: 'app-kid',
  templateUrl: './kid.component.html',
  styleUrls: ['./kid.component.css']
})
export class KidComponent implements OnInit, OnChanges, AfterContentInit, OnDestroy {
  @Input() city: string;
  constructor() {
    console.log('kid constructor called');
   }

  ngOnInit() {
    console.log('kid component initialized');
  }

  ngOnChanges(change: SimpleChanges) {
    console.log('kid On change');
  }

  ngAfterContentInit() {
    console.log('Kid AfterConente Init');
  }

  ngOnDestroy() {
    console.log('on Destroy');
  }

}
