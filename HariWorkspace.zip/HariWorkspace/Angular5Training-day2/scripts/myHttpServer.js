var http = require('http');
let server = http.createServer((request , response)=>{
    response.write("<h1>Node HTTP Server</h1>");
    response.end("<h2>Done for now</h2>");
});

server.listen(5000 , () => {
    console.log("server running at http://localhost:5000/");
});