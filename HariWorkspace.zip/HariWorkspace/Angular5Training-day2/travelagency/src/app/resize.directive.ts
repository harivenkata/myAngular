import { Directive, Renderer2, HostBinding, ElementRef, HostListener } from '@angular/core';
import { overrideComponentView } from '../../node_modules/@angular/core/src/view';

@Directive({
  selector: '[appResize]'
})
export class ResizeDirective {

  @HostBinding('class.card-img') showBorder = true;
  constructor(private element: ElementRef, private renderer: Renderer2) { }
  @HostListener('mouseover') over() {
    this.renderer.setStyle(this.element.nativeElement, 'width', '250px');
    this.renderer.setStyle(this.element.nativeElement, 'transition', 'width 2s');
    this.showBorder = false;
  }

  @HostListener('mouseout') out() {
    this.renderer.setStyle(this.element.nativeElement, 'width', '200px');
    this.showBorder = true;
  }
}
