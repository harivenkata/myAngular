import { Injectable, ComponentFactoryResolver, ViewContainerRef, ComponentFactory } from '@angular/core';
import { AgentApiService } from './agent-api.service';
import { AgentReviewComponent } from './agent-review/agent-review.component';

@Injectable({
  providedIn: 'root'
})
export class ComponentAdderService {
  viewContainer: ViewContainerRef;
  factory: ComponentFactory<{}>;

  constructor(private facResolver: ComponentFactoryResolver, private agentApiService: AgentApiService) { }

  setViewContainer(viewContainer: ViewContainerRef) {
    this.viewContainer = viewContainer;
  }

  addCompoenent(compToAdd: any, location) {
    this.viewContainer.clear();

    console.log('inside add component');
    this.factory = this.facResolver.resolveComponentFactory(compToAdd);
    const component = this.factory.create(this.viewContainer.parentInjector);
    this.agentApiService.findReviews(location).subscribe(
        data => (<AgentReviewComponent>component.instance).reviews =  data);
    this.viewContainer.insert(component.hostView);
  }
}
