export interface Weekendtrip {
    id: number; source: string; destination: string; fare: number;
}
