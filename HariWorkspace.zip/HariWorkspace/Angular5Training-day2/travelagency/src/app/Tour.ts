export interface Tour {
    tourName: string; description: string; image: string; price: number;
}
