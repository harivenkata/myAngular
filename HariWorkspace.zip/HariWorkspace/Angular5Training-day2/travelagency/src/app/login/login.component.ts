import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  constructor(private builder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.builder.group({
      userName: ['' , Validators.required],
      password: ['' , Validators.required]
    });
  }
  submit() {
    const name = this.loginForm.controls.userName.value;
    const pwd = this.loginForm.controls.password.value;
    if (name === pwd) {
      sessionStorage.setItem('isUserLogedin', 'true');
      this.router.navigate(['/holidays']);
    } else {
      this.router.navigate(['/login']);
    }
    console.log('value' + name);
    console.log('value' + pwd);
  }
}
