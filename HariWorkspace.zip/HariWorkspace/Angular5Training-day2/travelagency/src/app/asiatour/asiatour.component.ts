import { Component, OnInit } from '@angular/core';
import { TourAdvisorService } from '../tour-advisor.service';

@Component({
  selector: 'app-asiatour',
  templateUrl: './asiatour.component.html',
  styleUrls: ['./asiatour.component.css']
})
export class AsiatourComponent implements OnInit {

  constructor(private service: TourAdvisorService) { }

  ngOnInit() {
  }
suggest() {
  this.service.changeAdvice('Best time to visit asian countries: Aug - Dec');
}
}
