import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsiatourComponent } from './asiatour.component';

describe('AsiatourComponent', () => {
  let component: AsiatourComponent;
  let fixture: ComponentFixture<AsiatourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsiatourComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsiatourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
