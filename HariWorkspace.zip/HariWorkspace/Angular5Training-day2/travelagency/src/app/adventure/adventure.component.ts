import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';
import { Subscriber, Subscription } from '../../../node_modules/rxjs';

@Component({
  selector: 'app-adventure',
  templateUrl: './adventure.component.html',
  styleUrls: ['./adventure.component.css']
})
export class AdventureComponent implements OnInit, OnDestroy {
  val: any;
  subs: Subscription;
  details: string;

  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    console.log(this.router.routerState);
    this.subs = this.route.params.subscribe(myPram => {
    this.val = myPram['code'];
    if (this.val !== undefined) {
      this.details = 'Nice place to visit in summer';
    }
    });
  }
  ngOnDestroy() {
    this.subs.unsubscribe();
  }
}
