import { Component, OnInit } from '@angular/core';
import { Tour } from '../Tour';
import { TourAdvisorService } from '../tour-advisor.service';

@Component({
  selector: 'app-indiantour',
  templateUrl: './indiantour.component.html',
  styleUrls: ['./indiantour.component.css']
})
export class IndiantourComponent implements OnInit {
  indiaTours: Tour[];
  bestTime: string;
  indiaTourComponent: any;
  constructor(private service: TourAdvisorService) {
    this.indiaTours = [
      {tourName: 'Beautiful Kashmir', description: 'Lakes, mountains and Snow', image: 'assets/images/kashmir.jpg', price: 45000},
      {tourName: 'Devotional Thirupathi', description: 'Temples, Temples & Temples', image: 'assets/images/tirupathi.jpg', price: 5000},
      {tourName: 'Rajasthan', description: 'Forts & Temples', image: 'assets/images/rajasthan.jpg', price: 15000},
      {tourName: 'Great India Tour', description: 'Kashmir to Kanyakumari', image: 'assets/images/india.jpg', price: 150000}
    ];
   }

  ngOnInit() {
    this.service.myAdvice.subscribe(value => {
      this.bestTime = value;
    });
   }

  getIndianTours() {
    return this.indiaTours;
  }

}
