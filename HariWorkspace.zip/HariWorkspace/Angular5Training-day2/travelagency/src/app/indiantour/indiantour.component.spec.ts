import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndiantourComponent } from './indiantour.component';

describe('IndiantourComponent', () => {
  let component: IndiantourComponent;
  let fixture: ComponentFixture<IndiantourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndiantourComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndiantourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
