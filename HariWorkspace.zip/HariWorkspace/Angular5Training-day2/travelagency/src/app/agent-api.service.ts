import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '../../node_modules/@angular/common/http';
import { TravelAgent } from './travel-agent';
import { Observable } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgentApiService {

  baseUrl = 'http://localhost:3000/';
  constructor(private http: HttpClient) { }
  findAllAgents(): Observable<TravelAgent[]> {
    return this.http.get<TravelAgent[]> (this.baseUrl + 'agents');
  }

  findAgentById(id: number) {}
  addAgent(agent: TravelAgent): Observable<HttpResponse<{}>> {
    const headers = new HttpHeaders().set('content-type', 'application/json');
    return this.http.post<HttpResponse<{}>>(this.baseUrl + 'agents', agent, {headers});
  }
  removeAgent(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete<HttpResponse<{}>>(this.baseUrl + 'agents/' + id);
  }

  findReviews(location): Observable<HttpResponse<{}>> {
    return this.http.get<HttpResponse<{}>> (this.baseUrl + 'agentReview?location=' + location);
  }

  updateAgetDetails(agent: TravelAgent): Observable<HttpResponse<{}>> {
    const headers = new HttpHeaders().set('content-type', 'application/json');
    return this.http.put<HttpResponse<{}>>(this.baseUrl + 'agents/' + agent.id, agent, {headers});
  }
}
