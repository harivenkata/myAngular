import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-listcomponent',
  templateUrl: './listcomponent.component.html',
  styleUrls: ['./listcomponent.component.css']
})
export class ListcomponentComponent implements OnInit {
  @Input() listItems: string[];
  constructor() { }

  ngOnInit() {
  }

}
