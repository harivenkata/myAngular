import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-divine',
  templateUrl: './divine.component.html',
  styleUrls: ['./divine.component.css']
})
export class DivineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
