import { Directive, OnInit, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective implements OnInit {

  constructor(private element: ElementRef, renderer: Renderer2) { }
ngOnInit() {
  this.element.nativeElement.style.color = '#ff0000';
}
}
