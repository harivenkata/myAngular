import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  partner: string[] ;
  socialmedia: string[];
  constructor() {
    this.partner = ['Uber', 'Ola', 'Indigo', 'SpiceJet'];
    this.socialmedia = ['Facebook', 'Twitter', 'whatsapp', 'linkedin'];
  }

  ngOnInit() {
  }

}
