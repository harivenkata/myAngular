import { Component, OnInit, AfterContentInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ShowtripsService } from '../showtrips.service';
import { Weekendtrip } from '../weekendtrip';
import { Tour } from '../Tour';
import { IndiantourComponent } from '../indiantour/indiantour.component';

@Component({
  selector: 'app-holidays',
  templateUrl: './holidays.component.html',
  styleUrls: ['./holidays.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class HolidaysComponent implements OnInit, AfterContentInit {
  weekendTripList: Weekendtrip[];
  pickupPoints: string[];
  qty = 1;
  response: any;
  tours: Tour[];
  constructor(private service: ShowtripsService) { }
  @ViewChild(IndiantourComponent) indiaTour: IndiantourComponent;
  ngAfterContentInit(): void {
    this.tours = this.indiaTour.getIndianTours();
  }
  ngOnInit() {
    this.service.findAll().subscribe(resp => this.weekendTripList = resp);
  }
show(destination) {
  console.log(destination);
  this.pickupPoints = ['Miyapur', 'Nizampet', 'JNTU', 'KPHB'];
}
onChange(event) {
  this.response = event;
}
}
