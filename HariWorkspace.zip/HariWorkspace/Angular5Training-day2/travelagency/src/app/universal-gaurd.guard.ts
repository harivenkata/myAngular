import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UniversalGaurdGuard implements CanActivate, CanDeactivate<{}> {
  canDeactivate(compoenent: {}, currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot): boolean {
  return window.confirm('are you sure?');
}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      const status = localStorage.getItem('isUserLogedin');

      const url = state.url;
      if (url !== '/login' && status === 'true') {
        return true;
      } else {
        return false;
      }
  }

}
