import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heritage',
  templateUrl: './heritage.component.html',
  styleUrls: ['./heritage.component.css']
})
export class HeritageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
