import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  logo: string;
  currentDate = new Date();
  constructor() {
    this.logo = 'assets/images/logo.png';
    console.log('Header Component initialized');
   }

  ngOnInit() {
  }
  logout() {
    sessionStorage.removeItem('isUserLogedin');
  }

}
