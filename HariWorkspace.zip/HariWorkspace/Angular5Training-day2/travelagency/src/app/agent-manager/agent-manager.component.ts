import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AgentApiService } from '../agent-api.service';
import { TravelAgent } from '../travel-agent';
import { ComponentAdderService } from '../component-adder.service';
import { AgentReviewComponent } from '../agent-review/agent-review.component';

@Component({
  selector: 'app-agent-manager',
  templateUrl: './agent-manager.component.html',
  styleUrls: ['./agent-manager.component.css']
})
export class AgentManagerComponent implements OnInit {
  agentList: TravelAgent[];
  queryString = '';
  btnAction = true;
  @ViewChild('frm') frmRef: any;
  @ViewChild('placeholder', {read: ViewContainerRef}) viewRef: ViewContainerRef;
  agent: TravelAgent = {
    id: 0,
    name: '',
    location: '',
    phone: 0
  };
  editPox: number;
  buttonStatus = 'Add';
  isEdit = false;
  showDescard = false;
  toEdit: TravelAgent;
  constructor(private service: AgentApiService, private adderService: ComponentAdderService) { }

  ngOnInit() {
    this.fetch();
  }

  fetch() {
    this.service.findAllAgents().subscribe(data => this.agentList = data);
  }

  showDetails(location) {
    console.log('location' + location);
    this.adderService.setViewContainer(this.viewRef);
    this.adderService.addCompoenent(AgentReviewComponent, location);
  }
  submit(frmData) {
    this.agent = frmData;
    if (this.isEdit) {
      this.toEdit = frmData;
    //  this.agentList.splice(this.editPox, 0, this.toEdit);
      this.service.updateAgetDetails(this.agent).subscribe(resp =>  this.fetch());
    } else {
    console.log(this.agent);
    this.service.addAgent(this.agent).subscribe(resp =>  this.fetch() );
    }
  }

  deleteAgent(id: number) {
    this.service.removeAgent(id).subscribe(resp => this.fetch());
  }

  updateAgent(travelAgent) {
    this.agent = travelAgent;
    this.editPox = this.agentList.indexOf(this.agent);
    this.buttonStatus = 'Edit';
    this.isEdit = true;
    this.showDescard = true;
  }

  reset() {
    this.frmRef.reset();
  }



}
