import { Injectable } from '@angular/core';
import { BehaviorSubject } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class TourAdvisorService {
  advice: BehaviorSubject<string> = new BehaviorSubject<string>('Jan-Mar best time to visit');
  myAdvice = this.advice.asObservable();
  constructor() { }
  changeAdvice(chadv: string) {
    this.advice.next(chadv);
  }
}
