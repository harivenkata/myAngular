import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PocessorderComponent } from './pocessorder.component';

describe('PocessorderComponent', () => {
  let component: PocessorderComponent;
  let fixture: ComponentFixture<PocessorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PocessorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PocessorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
