import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-pocessorder',
  templateUrl: './pocessorder.component.html',
  styleUrls: ['./pocessorder.component.css']
})
export class PocessorderComponent implements OnInit {

  @Input() reqQty: number;
  @Output()  replyEvent: EventEmitter<string> = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
  }
processOrder() {
  this.replyEvent.emit(`${this.reqQty} of dinner will be served on board`);
}

}
