var sintRef = require('./interestCalculator');
var Book = require('./Book');
console.log(sintRef(2000,0.05,2));

var angular4=new Book(101,'NG-Book','Nade',45000);
var java=new Book(102,'JAVA','Hari',300);
var python=new Book(103,'Python','Venkat',400);
var react=new Book(104,'React','Kumar',900);

let bookList = [angular4,java,python,react];

for (var i=0;i<bookList.length;i++){
    console.log(bookList[i].bookName);
}

console.log("value of i:" + i);

for (let j=0;j<bookList.length;j++){
    console.log(bookList[j].bookName);
}
console.log("value of i:" + i);
//console.log("value of j:" + j);

