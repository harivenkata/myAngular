function simpleInterest(principle,years,rateOfInt){
    return principle * years * rateOfInt;
}

module.exports = simpleInterest;