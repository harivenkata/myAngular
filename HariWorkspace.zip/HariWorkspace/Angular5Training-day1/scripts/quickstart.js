
var app = {}; //global empty object using object literal syntax

//adding function to app variable
app.show = function (head) {
    console.log("inside show function");
    return head.toUpperCase();
};

app.init = function () {
    app.greetButton = document.getElementById("btn");
    app.greetButton.addEventListener('click' , app.update("Java Script"));
};

app.update = function (head) {
    return function(){
        var msg = document.getElementById("message");
        msg.innerHTML = app.show(head);
    };
};