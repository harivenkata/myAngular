var app=(function(){
    console.log("iife called");
    function greet() {
        return "Hello";
    }
    function curConverter(inr){
        return inr * 65.00;
    }
    console.log(greet());
    console.log(curConverter(200));

    return {
        myConverter: curConverter
    };
})();

console.log(app.myConverter(300));