// Customer Object using object literal syntax
//use IIFE
(function(){
    var customer = {
        customerId: 100,
        customerName: "Hari",
        toString: function(){
            return this.customerId + ' - ' + this.customerName;
        }
    };
    console.log(customer.toString());

//Product Object using Function Constructor 

    var Product = function(code, name, qty, rpu){
        this.code= code;
        this.name= name;
        this.qty= qty;
        this.rpu= rpu;
    };
    Product.prototype.calculate = function(){
        return this.qty * this.rpu;
    };
    Product.prototype.toString = function(){
        return this.code +','+ this.name +','+ this.qty +','+ this.rpu;
    };
    
    var cake = new Product(101,'Black Forest', 10, 450);
    var pakodi = new Product(102,'Onion Pakodi', 60, 5);
    var coke = new Product(103,'Coca Cola', 10, 25);
// Store in Array and display
    var items = [cake,pakodi,coke];

    items.forEach(function(eachItem, index){
        console.log(++index + ' - ' + eachItem + ' : ' + eachItem.calculate());
    });
})();







